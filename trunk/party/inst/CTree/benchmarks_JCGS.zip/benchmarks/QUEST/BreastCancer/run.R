
source("../R2guide.R")

data(BreastCancer, package = "mlbench")
BreastCancer = BreastCancer[,-1]
load("perfBreastCancer.rda")
e <- foo(BreastCancer, "Class", perf$bs)
print(e)
summary(e)

save(e, file = "qBreastCancer.rda")
     