

library(partylab)
library(rpart)
library(mlbench)
library(ipred)
library(mclust)
B = 500
set.seed(290875)

plrpbench <- function(data, B = 10, ic = "condasympt") {

    mf = ModelFrame(y ~ ., data = data)
    ls = ModelFrame2LearningSample(mf)

    ctrl = new("TreeControl",  
        actrl = new("AlgorithmControl",  
        mincriterion = 0.95,
        minsurrcriterion = 0.2,
        minprob = 0.01,
        inputcriterion = new("InputCriterion", teststatistic = "quadform", 
                             distribution = "condasympt"),
        nodecriterion = new("NodeCriterion", cMC = as.integer(1000), 
                            distribution = "Bonferroni")
    ),
    dctrl = new("DataControl", ls, # minsplit = 61,
        nsurrogate = as.integer(ifelse(any(is.na(data)), 5, 0)), 
        tiedmaxcrit = as.integer(min(10, floor(ls@ninputs/2))))
    )

    print(ctrl)

    bs = rmultinom(B, ls@nobs, rep.int(1, ls@nobs)/ls@nobs)

    perf <- matrix(0, ncol = 4, nrow = B)
    cc <- rep(0, B)
    ptree <- vector(length = B, mode = "list")
    rtree <- vector(length = B, mode = "list")

    for (i in 1:B) {
	print(i)
        oob = (bs[,i] == 0)
        pt <- try(mytree(ls, ctrl, bs[,i]))
        if (class(pt) != "try-error") {
            pr <- predict(pt, ls, type = "class")
            ptree[[i]] <- pt
            perf[i,3] <- length(pt@edges)
            perf[i,4] <- sum(pt@nodes[[1]]@criterion == 
                               max(pt@nodes[[1]]@criterion))/ls@ninputs
        if (is.factor(data$y))
            perf[i,1] <- mean((pr != data$y)[oob])
        else 
            perf[i,1] <- mean((pr - data$y)[oob]^2)
        } else {
            perf[i,c(1,3,4)] <- NA
        }

        tree = rpart(y ~ ., data = data, weights = bs[,i])
        rtree[[i]] <- tree
        if (is.factor(data$y))
            perf[i,2]  <- mean(predict(prune(tree, 
                            cp = tree$cptable[which.min(tree$cptable[,4]),1]), 
                      newdata = data[oob,], type = "class") != data$y[oob])
        else 
            perf[i,2]  <- mean((predict(prune(tree,
                            cp = tree$cptable[which.min(tree$cptable[,4]),1]),
                      newdata = data[oob,]) - data$y[oob])^2)

        if (class(pt) != "try-error")
            cc[i] <- nmi(pt@where, tree$where) ### compareClass(pt@where, tree$where)
        else
            cc[i] = NA
        cat(perf[i,1], " ", perf[i,2], " ", perf[i,4], "\n");
    }
    list(perf = perf, bs = bs, cc = cc) #, ptree = ptree, rtree = rtree)
}
