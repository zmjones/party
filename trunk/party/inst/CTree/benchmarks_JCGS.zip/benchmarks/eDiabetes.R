
source("cmp.R")
data(PimaIndiansDiabetes)
names(PimaIndiansDiabetes)[9] <- "y"
any(is.na(PimaIndiansDiabetes))
summary(PimaIndiansDiabetes)
perf <- plrpbench(PimaIndiansDiabetes, B = B)  
apply(perf$perf, 2, summary)
perf$name = "Diabetes"
save(perf, file = "perfDiabetes.rda")
warnings()

