
system("rm .RData")

files <- list.files()
runs <- files[grep("^e", files)]
if (length(grep("*Rout", runs)) > 0)
    runs <- runs[-grep("*Rout", runs)]

print(runs)

for (f in runs) {
    cmd <- paste("R CMD BATCH", f, " & ")
    print(cmd)
    Sys.sleep(2)
    print(system(cmd))
}

