
source("../R2guide.R")

data(Glass, package = "mlbench")
names(Glass)[10] <- "y"
load("perfGlass.rda")
e <- foo(Glass, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qGlass.rda")

