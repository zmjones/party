
cex <- 1.15
source("fieller.R")

library(lattice)

trellis.device("pdf", bg="white", file="ratiobox.pdf",
               horizontal=F, width=8, height=6)

# Farbe der Hintergruende der strips
strip.background <- trellis.par.get("strip.background")
strip.background$col <- c("white", "lightgray", "#c0fcf8", "#a8e0f8",
                            "#f8c0f8", "#f88c88", "#f8fcc0")
strip.background <- trellis.par.set("strip.background", strip.background)

box <- trellis.par.get("box.rectangle")
box$col <- ("black")
trellis.par.set("box.rectangle", box)

box <- trellis.par.get("box.umbrella")
box$col <- ("black")
trellis.par.set("box.umbrella", box)

box <- trellis.par.get("box.dot")
box$cex <- 0.5
trellis.par.set("box.dot", box)

box <- trellis.par.get("plot.symbol")
box$col <- ("black")
box$cex <- 0.5
trellis.par.set("plot.symbol", box)

axis <- trellis.par.get("axis.text")
axis$cex <- cex
trellis.par.set("axis.text", axis)

xlab <- trellis.par.get("par.xlab.text")
xlab$cex <- cex
trellis.par.set("par.xlab.text", xlab)


files <- list.files()
runs <- files[grep("^perf", files)]

pf <- c()
ds <- c()
i = 0
for (f in runs) {
    print(f)
    load(f)
    ds <- c(ds, perf$name)
    pf <- rbind(pf, cbind(perf$perf[,1:2], perf$cc, i))
    i = i + 1
}
pf <- as.data.frame(pf)
names(pf) <- c("partylab", "rpart", "meila", "dataset")
### change ordering of the levels for bwplot
pf$dataset <- -(pf$dataset - 11)
pf$dataset <- factor(pf$dataset)
levels(pf$dataset) <- rev(ds)

ci <- c()
pf <- pf[complete.cases(pf),]
for (lev in levels(pf$dataset)) {
    print(lev)
    ci <- rbind(ci, c(mean(pf$partylab[pf$dataset == lev])/
                    mean(pf$rpart[pf$dataset == lev]), 
                    fieller(pf$partylab[pf$dataset == lev], pf$rpart[pf$dataset == lev], 
                  paired = TRUE, conf.level = 0.9)))
}
rownames(ci) <- levels(pf$dataset)
colnames(ci) <- c("ratio", "5\\%", "95\\%")
ci <- as.data.frame(round(ci, 3)[nrow(ci):1,])

ratio <- pf$partylab / pf$rpart
mr <- max(ratio)

ord <- rev(levels(pf$dataset)[c(12,6,5,11,10,9,8,7,4,3,2,1)])
ci <- ci[rev(ord),]

library("grid")
bwplot(factor(dataset, levels = ord) ~ ratio, data = pf, xlim = c(0, 5.7), 
       panel=function(x,y,...) {
           panel.abline(v=1, lty = 2)
           panel.abline(h=9.5, lty = 1)
           panel.bwplot(x,y,...)
           signif <- ci[,2] > 0.9 & ci[,3] < 1.1
           ltext(rep(mr + 0.9, length(unique(y))), length(unique(y)):1, 
                 paste(formatC(ci[,1], dig = 3, format = "f"), 
                       " (", ci[,2], ", ", ci[,3], ") ", 
                       ifelse(signif, "*", " "), sep=""))
           grid.text("Regression", 0.97, 0.87, rot = 270)
           grid.text("Classification", 0.97, 0.40, rot = 270)
       }, xlab = "Performance ratio")

dev.off()

