
goodman <- function(x, conf.level = 0.95) {

    k <- length(x)
    n <- sum(x)
    q <- qchisq(1 - (1 - conf.level) / k, df = 1)

    a <- sqrt(q) * sqrt(q + 4 * x * (n - x)/n)

    lower <- (q + 2 * x - a) / (2 * (n + q))
    upper <- (q + 2 * x + a) / (2 * (n + q))

    RET <- data.frame(lower = lower, upper = upper)
    RET
}

