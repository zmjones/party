
wd <- getwd()

ds <- c("Boston", "BreastCancer", "Glass", "Ionosphere", "Sonar", "Vehicle", 
        "Diabetes", "Glaucoma", "Ozone", "Servo", "Soybean", "Vowel")

p <- c()
dataset <- c()

for (d in ds) {

    print(d)
    setwd(file.path(wd, d))

    load(list.files(pattern = "^[p].*rda"))
    load(list.files(pattern = "^[q].*rda"))

    out <- cbind(perf$perf[,1:2], e)
    rm(e)
    print(100 - apply(out, 2, mean, na.rm = TRUE)*100)

    p <- rbind(p, out)
    dataset <- c(dataset, rep(perf$name, nrow(out)))
    rm(perf)

}
colnames(p) <- c("partylab", "rpart", "quest")

qret <- data.frame(p, dataset)
setwd(wd)

save(qret, file = "qret.rda")

