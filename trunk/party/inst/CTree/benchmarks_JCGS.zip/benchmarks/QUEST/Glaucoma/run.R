
source("../R2guide.R")

data(GlaucomaM, package = "ipred")
load("perfGlauc.rda")
e <- foo(GlaucomaM, "Class", perf$bs)
print(e)
summary(e)


save(e, file = "qGlaucoma.rda")
