
source("cmp.R")

data(BostonHousing)
names(BostonHousing)[14] <- "y"
any(is.na(BostonHousing))
summary(BostonHousing)
perf <- plrpbench(BostonHousing, B = B)
apply(perf$perf, 2, summary)
perf$name = "Boston Housing"
save(perf, file = "perfBoston.rda")
warnings()
