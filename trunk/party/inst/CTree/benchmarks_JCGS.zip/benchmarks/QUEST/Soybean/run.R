
source("../R2guide.R")

data(Soybean, package = "mlbench")
names(Soybean)[names(Soybean) == "Class"] <- "y"
levels(Soybean$y) <- abbreviate(levels(Soybean$y))
load("perfSoybean.rda")
e <- foo(Soybean, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qSoybean.rda")
