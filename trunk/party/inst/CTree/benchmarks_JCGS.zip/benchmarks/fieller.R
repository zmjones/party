
set.seed(290875)
library(mvtnorm)
fieller <- function(x, y, paired = FALSE, conf.level = 0.95) {

    mx <- mean(x)
    n  <- length(x)
    my <- mean(y)
    m <- length(y)
    sx <- var(x)/n
    sy <- var(y)/m
    sxy <- ifelse(paired, var(cbind(x,y))[1,2], 0) / n
    
    alpha <- (1 - conf.level)
    quant <- (qnorm(alpha/2))^2

    tmp <- (mx*my - quant * sxy)^2 - (mx^2 - quant*sx)*(my^2 - quant * sy)
    if (tmp <= 0) return(c(NA,NA))
    ci <- mx * my - quant * sxy + 
          c(-1, 1) * sqrt(tmp)
    ci <- ci / (my^2 - quant * sy)
    attr(ci, "conf.level") <- conf.level
    ci
}

if (FALSE) {
p <- 0
n <- 20000
m <- c(20, 10)
sigma <- diag(2)
sigma[1,2] <- sigma[2,1] <- 0
print(sigma)
for (i in 1:n) {
    rn <- rmvnorm(50, m, sigma)
    x <- fieller(rn[,1], rn[,2], paired = FALSE)
    p = p + (x[1] > m[1] / m[2] || x[2] < m[1] / m[2])
}
print(p / n)
}