
source("../R2guide.R")

data(Vehicle, package = "mlbench")
load("perfVehicle.rda")
e <- foo(Vehicle, "Class", perf$bs)
print(e)
summary(e)

save(e, file = "qVehicle.rda")

