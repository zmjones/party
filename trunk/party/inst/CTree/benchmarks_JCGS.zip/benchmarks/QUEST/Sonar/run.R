
source("../R2guide.R")

data(Sonar, package = "mlbench")
names(Sonar)[names(Sonar) == "Class"] <- "y"
load("perfSonar.rda")
e <- foo(Sonar, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qSonar.rda")

