
cex <- 1.15
source("fieller.R")

library(lattice)

trellis.device("pdf", bg="white", file="ratiobox.pdf",
               horizontal=F, paper="a4", width=8, height=6)

# Farbe der Hintergruende der strips
strip.background <- trellis.par.get("strip.background")
strip.background$col <- c("white", "lightgray", "#c0fcf8", "#a8e0f8",
                            "#f8c0f8", "#f88c88", "#f8fcc0")
strip.background <- trellis.par.set("strip.background", strip.background)

box <- trellis.par.get("box.rectangle")
box$col <- ("black")
trellis.par.set("box.rectangle", box)

box <- trellis.par.get("box.umbrella")
box$col <- ("black")
trellis.par.set("box.umbrella", box)

box <- trellis.par.get("box.dot")
box$cex <- 0.5
trellis.par.set("box.dot", box)

box <- trellis.par.get("plot.symbol")
box$col <- ("black")
box$cex <- 0.5
trellis.par.set("plot.symbol", box)

axis <- trellis.par.get("axis.text")
axis$cex <- cex
trellis.par.set("axis.text", axis)

xlab <- trellis.par.get("par.xlab.text")
xlab$cex <- cex
trellis.par.set("par.xlab.text", xlab)


load("qret.rda")
pf <- qret
# names(pf) <- c("partylab", "rpart", "meila", "dataset")
### change ordering of the levels for bwplot
ds <- levels(pf$dataset)
dummy <- -(as.numeric(pf$dataset) - 8)
dummy <- factor(dummy)
levels(dummy) <- rev(ds)
all(dummy == pf$dataset)
pf$dataset <- dummy
#pf$dataset <- -(pf$dataset - 11)
#pf$dataset <- factor(pf$dataset)
#levels(pf$dataset) <- rev(ds)

ci <- c()
pf <- pf[complete.cases(pf),]
for (lev in levels(pf$dataset)) {
    print(lev)
    ci <- rbind(ci, c(mean(pf$partylab[pf$dataset == lev])/
                    mean(pf$quest[pf$dataset == lev]), 
                    fieller(pf$partylab[pf$dataset == lev], pf$quest[pf$dataset == lev], 
                  paired = TRUE, conf.level = 0.9)))
}
rownames(ci) <- levels(pf$dataset)
colnames(ci) <- c("ratio", "5\\%", "95\\%")
ci <- as.data.frame(round(ci, 3)[nrow(ci):1,])

ratio <- pf$partylab / pf$quest
ratio[ratio > 3.5] <- 3.5
mr <- max(ratio)
bwplot(dataset ~ ratio, data = pf, xlim = c(0, 5), 
       panel=function(x,y,...) {
           panel.abline(v=1, lty = 2)
           panel.bwplot(x,y,...)
           signif <- ci[,2] > 0.9 & ci[,3] < 1.1
           ltext(rep(mr + 0.7, length(unique(y))), length(unique(y)):1,  
                 paste(formatC(ci[,1], dig = 3, format = "f"), 
                       " (", formatC(ci[,2], dig = 3, format = "f"),
                        ", ", formatC(ci[,3], dig = 3, format = "f"), ") ", 
                       ifelse(signif, "*", " "), sep=""))
       }, xlab = "Performance ratio")

dev.off()

