mu <-  0.2 
 
source("core.in") 
 
ret <- loop(Nsim, mu) 
attach(ret) 
 
table(srpart) / Nsim 
1 - mean(split) 
mean(srpart == "V6" & split) 
 
table(sctree) / Nsim 
mean(pvalue < 0.05)  
mean(sctree == "V6" & pvalue < 0.05) 
 
save(ret, file = paste("ret_", mu, ".rda", sep = "")) 
 
