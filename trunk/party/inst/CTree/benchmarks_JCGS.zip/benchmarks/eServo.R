
source("cmp.R")

data(Servo)
names(Servo)[5] <- "y"
any(is.na(Servo))
summary(Servo)
perf <- plrpbench(Servo, B = B)
apply(perf$perf, 2, summary)
perf$name = "Servo"
save(perf, file = "perfServo.rda")
warnings()
