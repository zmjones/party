
source("../R2guide.R")

data(Vowel, package = "mlbench")
load("perfVowel.rda")
e <- foo(Vowel, "Class", perf$bs)
print(e)
summary(e)

save(e, file = "qVowel.rda")

