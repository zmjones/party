
source("goodman.R")

mu <- seq(from = 0, to = 1, by = 0.1)
try(rm(ret))
Nsim <- 10000
out <- c()
frpart <- c()
fctree <- c()

for (m in mu) {
    load(paste("ret_", m, ".rda", sep =""))
    out <- rbind(out, 
                 c(1 - mean(ret$split),
                 sum(ret$srpart == "V6" & !ret$split) / sum(!ret$split),
                 mean(ret$pvalue < 0.05), 
                 sum(ret$sctree == "V6" & ret$pvalue < 0.05) /
                      sum(ret$pvalue < 0.05)))
    frpart <- rbind(frpart, table(ret$srpart) / Nsim)
    fctree <- rbind(fctree, table(ret$sctree) / Nsim)
    rm(ret)

}

rownames(out) <- mu
colnames(out) <- c("split_rpart", "correct_rpart", 
                   "split_ctree", "correct_ctree")
out <- as.data.frame(out)

pdf("power_split.pdf", width = 8, height = 5)

cex <- 1.15
# cex <- cex * 1.2

layout(matrix(1:2, nc = 2))
plot(mu, out[["split_rpart"]], type = "l", lty = 1, ylim = c(0,1), 
     # main = "Power", 
     ylab = "Simulated Power", xlab = expression(mu), cex.axis = cex,
     cex.lab = cex)
lines(mu, out[["split_ctree"]], lty = 2)
abline(h = 0.05, lty = 3)
legend(0.01, 0.99, lty = c(1, 2), legend = c("rpart", "cond. inf. trees"),
       cex = 1, bty = "n")

plot(mu, out[["correct_rpart"]], type = "l", lty = 1, ylim = c(0,1), 
     # main = "Correct Split", 
     ylab = "Conditional Probability of Correct Split", xlab =
     expression(mu), cex.axis = cex, cex.lab = cex)
lines(mu, out[["correct_ctree"]], lty = 2)

dev.off()

print(out)

print(frpart)
print(fctree)

c1 <- round(goodman(frpart[1,] * Nsim), 3)
c2 <- round(goodman(fctree[1,] * Nsim), 3)


selprob <- cbind(frpart[1,], c1[,1], c1[,2], fctree[1,], c2[,1], c2[,2])
# rownames(selprob) <- c("rpart", "Conditional Inference Tree")

library(xtable)
xtable(selprob, digits = rep(3, 7))


