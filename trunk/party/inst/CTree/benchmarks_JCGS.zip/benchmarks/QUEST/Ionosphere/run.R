
source("../R2guide.R")

data(Ionosphere, package = "mlbench")
names(Ionosphere)[names(Ionosphere) == "Class"] <- "y"
Ionosphere$V2 <- NULL
load("perfIonos.rda")
e <- foo(Ionosphere, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qIonos.rda")

