
source("../R2guide.R")

data(Servo, package = "mlbench")
names(Servo)[5] <- "y"
load("perfServo.rda")
e <- foo(Servo, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qServo.rda")
