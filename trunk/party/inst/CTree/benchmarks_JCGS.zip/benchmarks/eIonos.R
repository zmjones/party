
source("cmp.R")

data(Ionosphere)
names(Ionosphere)[names(Ionosphere) == "Class"] <- "y"
Ionosphere$V2 <- NULL
any(is.na(Ionosphere))
summary(Ionosphere)
perf <- plrpbench(Ionosphere, B = B)
perf$name = "Ionosphere"
apply(perf$perf, 2, summary)
save(perf, file = "perfIonos.rda")
warnings()
