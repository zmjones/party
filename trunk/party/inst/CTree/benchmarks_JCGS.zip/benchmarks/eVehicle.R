

source("cmp.R")

data(Vehicle)
names(Vehicle)[names(Vehicle) == "Class"] <- "y"
any(is.na(Vehicle))
summary(Vehicle)
perf <- plrpbench(Vehicle, B = B, ic = "Bonferroni")   
apply(perf$perf, 2, summary)
perf$name = "Vehicle"
save(perf, file = "perfVehicle.rda")
warnings()
