
wd <- getwd()

ds <- c("Boston", "Ozone", "Servo")

p <- c()
dataset <- c()

for (d in ds) {

    print(d)
    setwd(file.path(wd, d))

    load(list.files(pattern = "^[p].*rda"))
    load(list.files(pattern = "^[q].*rda"))

    out <- cbind(perf$perf[,1:2], e)
    rm(e)
    print(apply(out, 2, mean, na.rm = TRUE))

    p <- rbind(p, out)
    dataset <- c(dataset, rep(perf$name, nrow(out)))
    rm(perf)

}
colnames(p) <- c("partylab", "rpart", "quest")

qret <- data.frame(p, dataset)
setwd(wd)

save(qret, file = "qret.rda")

