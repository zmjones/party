
library(coin)
library(vcd)
library(xtable)

load("ret.rda")


print(mean(ret$crpart))
print(mean(ret$cctree))

ret$ntrpart[ret$ntrpart >= 7] <- 7
ret$ntrctree[ret$ntctree >= 7] <- 7

lev <- as.character(sort(unique(c(ret$ntrpart, ret$ntctree))))
lev[length(lev)] <- ">= 7"
ret$ntrpart <- ordered(ret$ntrpart, labels = lev)
ret$ntctree <- ordered(ret$ntctree, levels = lev)

table(ret[["ntrpart"]])
table(ret[["ntctree"]])
rpart <- ret[["ntrpart"]]
ctree <- ret[["ntctree"]]
tab <- table(rpart, ctree)
tab

xtab <- rbind(cbind(as.matrix(tab), rowSums(tab)), 
              c(colSums(tab), sum(tab)))
xtable(xtab, digits = rep(0, 8))

mosaicplot(tab)

mh <- mh_test(tab,
              xtrafo = function(data)
                  trafo(data, factor_trafo = function(x) 
                      model.matrix( ~ x - 1)
                  )
             )
print(mh)

ls <- statistic(mh, type = "linear")
els <- expectation(mh)
cls <- covariance(mh)
(ls - els) / sqrt(diag(cls))

eq <- subset(ret, nmirpart - nmictree == 0)
dim(eq)
max(abs(eq$nmirpart - eq$nmictree))

dif <- subset(ret, nmirpart - nmictree != 0)
dim(dif)
cex <- 1.15 * 1.2
pdf("nmisim.pdf", width = 8, height = 6)
plot(density(dif$nmirpart - dif$nmictree), main = "", 
     xlab = "NMI (rpart, true) - NMI (conditional inference tree, true)", 
     cex.axis = cex, cex.lab = cex)
abline(v = 0, lty = 2)
dev.off()
