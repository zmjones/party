
library(partylab2)
load("perfGlauc.rda")

data(GlaucomaM, package = "ipred")
b <- perf$bs[,1]

ct <- ctree(Class ~ ., data = GlaucomaM, weights = as.double(b))
pr <- predict(ct, newdata = GlaucomaM[b == 0,])

mean(pr != GlaucomaM[b == 0,"Class"])
perf$perf[1]



