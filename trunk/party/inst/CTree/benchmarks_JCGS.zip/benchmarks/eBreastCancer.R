

source("cmp.R")

data(BreastCancer)
BreastCancer = BreastCancer[,-1]
names(BreastCancer)[names(BreastCancer) == "Class"] <- "y"
any(is.na(BreastCancer))
summary(BreastCancer)
perf <- plrpbench(BreastCancer, B = B, ic = "Bonferroni")   
apply(perf$perf, 2, summary)
perf$name = "Breast Cancer"
save(perf, file = "perfBreastCancer.rda")
warnings()
