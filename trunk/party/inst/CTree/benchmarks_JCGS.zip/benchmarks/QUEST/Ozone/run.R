
source("../R2guide.R")

data(Ozone, package = "mlbench")
names(Ozone)[4] <- "y"
Ozone <- Ozone[!is.na(Ozone$y),]
any(is.na(Ozone))

load("perfOzone.rda")
e <- foo(Ozone, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qOzone.rda")
