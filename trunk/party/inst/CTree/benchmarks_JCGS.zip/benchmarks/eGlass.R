

source("cmp.R")

data(Glass)
names(Glass)[10] <- "y"
any(is.na(Glass))
summary(Glass)
perf <- plrpbench(Glass, B = B)   
apply(perf$perf, 2, summary)
perf$name = "Glass"
save(perf, file = "perfGlass.rda")
warnings()
