
files <- list.files(pattern = "*perf")
for (f in files) {

   print(f)
   load(f)
   print(apply(perf$perf[,1:2], 2, mean, na.rm = TRUE))

}

