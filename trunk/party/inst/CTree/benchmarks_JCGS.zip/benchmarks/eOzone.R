
source("cmp.R")

data(Ozone)
names(Ozone)[4] <- "y"
Ozone <- Ozone[!is.na(Ozone$y),]
any(is.na(Ozone))
summary(Ozone)
perf <- plrpbench(Ozone, B = B, ic = "Bonferroni")
apply(perf$perf, 2, summary)
perf$name = "Ozone"
save(perf, file = "perfOzone.rda")
warnings()
