
source("cmp.R")
data(GlaucomaM)
any(is.na(GlaucomaM))
names(GlaucomaM)[names(GlaucomaM) == "Class"] <- "y"
summary(GlaucomaM)
perf <- plrpbench(GlaucomaM, B = B)
apply(perf$perf, 2, summary)
perf$name = "Glaucoma"
save(perf, file = "perfGlauc.rda")
warnings()
