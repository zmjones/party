
source("cmp.R")
data(Sonar)
names(Sonar)[names(Sonar) == "Class"] <- "y"
any(is.na(Sonar))
summary(Sonar)
perf <- plrpbench(Sonar, B = B)
apply(perf$perf, 2, summary)
perf$name = "Sonar"
save(perf, file = "perfSonar.rda")
warnings()
