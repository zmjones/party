
source("cmp.R")

data(Vowel)
any(is.na(Vowel))
names(Vowel)[names(Vowel) == "Class"] <- "y"
summary(Vowel)
perf <- plrpbench(Vowel, B = B)
perf$name = "Vowel"
apply(perf$perf, 2, summary)
save(perf, file = "perfVowel.rda")
warnings()
