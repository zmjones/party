
source("cmp.R")

data(Soybean)
any(is.na(Soybean))
names(Soybean)[names(Soybean) == "Class"] <- "y"
summary(Soybean)
perf <- plrpbench(Soybean, B = B, ic = "Bonferroni")
apply(perf$perf, 2, summary)
perf$name = "Soybean"
save(perf, file = "perfSoybean.rda")
warnings()
