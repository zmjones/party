
cex <- 1.15
source("fieller.R")

library(lattice)

#trellis.device("pdf", bg="white", file="ratiobox.pdf",
#               horizontal=F, paper="a4", width=6, height=6)

# Farbe der Hintergruende der strips
strip.background <- trellis.par.get("strip.background")
strip.background$col <- c("white", "lightgray", "#c0fcf8", "#a8e0f8",
                            "#f8c0f8", "#f88c88", "#f8fcc0")
strip.background <- trellis.par.set("strip.background", strip.background)

box <- trellis.par.get("box.rectangle")
box$col <- ("black")
trellis.par.set("box.rectangle", box)

box <- trellis.par.get("box.umbrella")
box$col <- ("black")
trellis.par.set("box.umbrella", box)

box <- trellis.par.get("box.dot")
box$cex <- 0.5
trellis.par.set("box.dot", box)

box <- trellis.par.get("plot.symbol")
box$col <- ("black")
box$cex <- 0.5
trellis.par.set("plot.symbol", box)

axis <- trellis.par.get("axis.text")
axis$cex <- cex
trellis.par.set("axis.text", axis)

xlab <- trellis.par.get("par.xlab.text")
xlab$cex <- cex
trellis.par.set("par.xlab.text", xlab)


files <- list.files()
runs <- files[grep("^perf", files)]

pf <- c()
ds <- c()
i = 0
for (f in runs) {
    print(f)
    load(f)
    ds <- c(ds, perf$name)
    pf <- rbind(pf, cbind(perf$perf[,1:2], perf$cc, i))
    i = i + 1
}
pf <- as.data.frame(pf)
names(pf) <- c("partylab", "rpart", "meila", "dataset")
### change ordering of the levels for bwplot
pf$dataset <- -(pf$dataset - 11)
pf$dataset <- factor(pf$dataset)
levels(pf$dataset) <- rev(ds)
ratio <- pf$partylab / pf$rpart
#bwplot(dataset ~ ratio, data = pf, 
#       panel=function(x,y,...) {
#           panel.abline(v=1, lty = 2)
#           panel.bwplot(x,y,...)
#       }, xlab = "Performance ratio")
#
#dev.off()

xlim = cbind(pmin(tapply(pf$rpart, pf$dataset, min, na.rm = TRUE), 
                  tapply(pf$partylab, pf$dataset, min, na.rm = TRUE)) * 0.95,
             pmax(tapply(pf$rpart, pf$dataset, min, na.rm = TRUE), 
                  tapply(pf$partylab, pf$dataset, max, na.rm = TRUE)) * 1.05)

lim <- vector(mode = "list", length = nrow(xlim))
for (i in 1:length(lim))
    lim[[i]] <- xlim[i,]
names(lim) <- rownames(xlim)

CL <- c("BreastCancer",   "Glass",          "Glaucoma",      
          "Ionosphere",     "Diabetes",     "Vehicle",           
          "Sonar",          "Soybean",        "Vowel")

Class <- pf$dataset %in% CL

trellis.device("pdf", bg="white", file="xyboxClass.pdf",
               horizontal=F, paper="a4", width=6, height=6)

# Farbe der Hintergruende der strips
strip.background <- trellis.par.get("strip.background")
strip.background$col <- c("white", "lightgray", "#c0fcf8", "#a8e0f8",
                            "#f8c0f8", "#f88c88", "#f8fcc0")
strip.background <- trellis.par.set("strip.background", strip.background)

dot <- trellis.par.get("plot.symbol")
dot$col <- ("gray")
dot$cex <- 0.5
dot$pch <- 4
trellis.par.set("plot.symbol", dot)

xyplot(rpart ~ partylab | dataset, data = pf[Class,], scales = list(relation =
         "free"), xlab = "Error partylab", ylab = "Error rpart", 
         xlim = lim[names(lim) %in% CL], ylim = lim[names(lim) %in% CL], 
         between = list(x = 0.75, y = 0.75))

dev.off()

trellis.device("pdf", bg="white", file="xyboxReg.pdf",
               horizontal=F, paper="a4", width=6, height=6)

# Farbe der Hintergruende der strips
strip.background <- trellis.par.get("strip.background")
strip.background$col <- c("white", "lightgray", "#c0fcf8", "#a8e0f8",
                            "#f8c0f8", "#f88c88", "#f8fcc0")
strip.background <- trellis.par.set("strip.background", strip.background)

dot <- trellis.par.get("plot.symbol")
dot$col <- ("gray")
dot$cex <- 0.5
dot$pch <- 4
trellis.par.set("plot.symbol", dot)

xyplot(rpart ~ partylab | dataset, data = pf[!Class,], scales = list(relation =
         "free"), xlab = "Error partylab", ylab = "Error rpart", 
         xlim = lim[!(names(lim) %in% CL)], ylim = lim[!(names(lim) %in% CL)], 
         between = list(x = 0.75, y = 0.75))

dev.off()

### CI:

ci <- c()
pf <- pf[complete.cases(pf),]
for (lev in levels(pf$dataset)) {
    print(lev)
    ci <- rbind(ci, c(mean(pf$partylab[pf$dataset == lev])/
                    mean(pf$rpart[pf$dataset == lev]), 
                    fieller(pf$partylab[pf$dataset == lev], pf$rpart[pf$dataset == lev], 
                  paired = TRUE, conf.level = 0.9)))
}
rownames(ci) <- levels(pf$dataset)
colnames(ci) <- c("ratio", "5\\%", "95\\%")
library(xtable)
print(xtable(ci, digits = c(3,3,3,3)))

### density estimator

library(KernSmooth)
x <- cbind(pf$partylab / pf$rpart, pf$meila)
dx1 <- density(x[,1])
dx2 <- density(x[,2])

pdf("nmiratio_shaded.pdf", width = 6, height = 6, version = "1.4")
plot(x[,1], x[,2], col = rgb(0,0,0, 0.2))
dev.off()


est <- bkde2D(x, bandwidth=c(dx1$bw*4, dx2$bw*4),
              range.x = list(c(0, 2), c(0,1)))

pdf("nmiratiodens.pdf", width = 6, height = 6)
cex <- cex * 1.2
bottom <- 5
left <- 4.5
topright <- 0.15
par(mar=c(bottom,left,topright,topright))
layout(matrix(c(2,0,1,3),2,2,byrow=TRUE), c(3,1), c(1,3), TRUE)
image(est$x1, est$x2, est$fhat,
      col = gray(rev(seq(from = 0.3^2.2, to = 1^2.2, by = 0.01))),
      xlab = "Performance ratio", ylab = "NMI", cex = cex, cex.axis = cex,
      cex.lab = cex)
box()
# contour(est$x1, est$x2, est$fhat, add = TRUE) #, nlevels = 5)
par(mar=c(0,left,topright,topright))
#boxplot(x[,1], axes = FALSE, horizontal = TRUE, pars = list(ylim = c(0,2)),
#        range = 0, cex = cex)
# plot(density(x[,1]), axes = FALSE, ylab = NULL, main = NULL, xlim = c(0,2))
dx <- density(x[,1])
plot(dx$x, dx$y, type = "l", axes = FALSE, xlim = c(0,2), ylab = "", cex.axis =
cex)
par(mar=c(bottom,0,topright,topright))
#boxplot(x[,2], axes = FALSE, pars = list(ylim = c(0,1)), cex = cex, range =
#0)
# plot(density(x[,2]), axes = FALSE, xlim = c(0,1), ylab = NULL, main = NULL)
dx <- density(x[,2])
plot(dx$y, dx$x, type = "l", axes = FALSE, ylim = c(0,1), ylab = "", xlab =
"", cex.axis = cex)
dev.off()

save(pf, file = "pf.rda")

