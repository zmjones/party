

library(partylab)
library(rpart)
library(mlbench)
library(ipred)
library(mclust)
B = 100
set.seed(290875)


data(Soybean)
any(is.na(Soybean))
names(Soybean)[names(Soybean) == "Class"] <- "y"
data <- Soybean

    mf = ModelFrame(y ~ ., data = data)
    ls = ModelFrame2LearningSample(mf)

   ctrl = new("TreeControl",
        actrl = new("AlgorithmControl",
        mincriterion = 0.95,
        minsurrcriterion = 0.2,
        minprob = 0.01,
        inputcriterion = new("InputCriterion", teststatistic = "quadform",
                             distribution = "condasympt"),
        nodecriterion = new("NodeCriterion", cMC = as.integer(1000),
                            distribution = "Bonferroni")
    ),
    dctrl = new("DataControl", ls,
        nsurrogate = as.integer(ifelse(any(is.na(data)), 5, 0)),
        tiedmaxcrit = as.integer(min(10, floor(ls@ninputs/2))))
    )

    print(ctrl)

        pt = mytree(ls, ctrl)
        pr <- predict(pt, ls, type = "class")
        if (is.factor(data$y)) {
            mean((pr != data$y))
        } else { 
            mean((pr - data$y)^2)
        }

a <- pt@where
b <- .Call("getNodeNumbers", pt, ls)
all.equal(a, b)

        tree = rpart(y ~ ., data = data)
        if (is.factor(data$y)) {
            mean((p <- predict(prune(tree, 
                            cp = tree$cptable[which.min(tree$cptable[,4]),1]), 
                      newdata = data, type = "class")) != data$y)
        } else { 
            mean(((p <- predict(prune(tree,
                            cp = tree$cptable[which.min(tree$cptable[,4]),1]),
                      newdata = data)) - data$y)^2)
        }

na <- complete.cases(data)
mean((pr != data$y)[!na])
mean((p != data$y)[!na])


unlist(lapply(pt@nodes, function(x) if (extends(class(x), "SplittingNode"))
length(x@surrogatesplits)))