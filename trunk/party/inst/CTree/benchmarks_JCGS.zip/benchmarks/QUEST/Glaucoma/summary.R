
load(list.files(pattern = "^[p].*rda"))
load(list.files(pattern = "^[q].*rda"))

out <- cbind(perf$perf[,1:2], e)
colnames(out) <- c("ctree", "rpart", "quest")
apply(out, 2, mean, na.rm = TRUE)

boxplot(out[,1] / out[,3], horizontal = TRUE)
abline(v = 1)
