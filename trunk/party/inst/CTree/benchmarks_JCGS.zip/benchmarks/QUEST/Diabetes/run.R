
source("../R2guide.R")

data(PimaIndiansDiabetes, package = "mlbench")
names(PimaIndiansDiabetes)[9] <- "y"
load("perfDiabetes.rda")
e <- foo(PimaIndiansDiabetes, "y", perf$bs)
print(e)
summary(e)

save(e, file = "qDiabetes.rda")

