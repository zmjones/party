
source("../R2guide.R")

data(BostonHousing, package = "mlbench")
load("perfBoston.rda")
e <- foo(BostonHousing, "medv", perf$bs)
print(e)
summary(e)

save(e, file = "qBoston.rda")
