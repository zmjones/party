
library(rpart)
library(partylab2)
library(coin)

Nsim <- 1000
set.seed(290875)

foo <- function(n, sd = 1) {
    df <- as.data.frame(matrix(runif(n * 5), ncol = 5))
    df$V6 <- gl(2, n/2)
    df$V3[sample(1:n, n/4)] <- NA
    df$V4 <- round(df$V4, 1)
    df$y <- rep(0, n)

    where <- rep(0, n)
    where[df$V6 == "1" & df$V1 < 0.5] <- 1
    where[df$V6 == "1" & df$V1 >= 0.5] <- 2
    where[df$V6 == "2" & df$V2 < 0.5] <- 3
    where[df$V6 == "2" & df$V2 >= 0.5] <- 4

    df$y[where == 1] <- rnorm(sum(where == 1), mean = 1, sd = sd)
    df$y[where == 2] <- rnorm(sum(where == 2), mean = 2, sd = sd)
    df$y[where == 3] <- rnorm(sum(where == 3), mean = 3, sd = sd)
    df$y[where == 4] <- rnorm(sum(where == 4), mean = 4, sd = sd)
    attr(df, "where") <- where
    df
}

crrpart <- function(x) {
    left <- all(x$frame$var[1:2] == c("V6", "V1"))
    a <- x$frame[-(1:2),]
    (left && a$var[which.max(a$n)] == "V2") & (nrow(x$frame) == 7)
}

crctree <- function(x) {
     two <- c(x@tree$left$psplit$variableName, x@tree$right$psplit$variableName)
     all(c(x@tree$psplit$variableName == "V6", c("V1", "V2") %in% two, nterminal(x@tree) == 4))
}

loop <- function(Nsim, sd = 1) {

    nmirpart <- vector(mode = "numeric", length = Nsim)
    nmictree <- vector(mode = "numeric", length = Nsim)
    ntrpart <- vector(mode = "numeric", length = Nsim)
    ntctree <- vector(mode = "numeric", length = Nsim)

    crpart <- vector(mode = "logical", length = Nsim)
    cctree <- vector(mode = "logical", length = Nsim)


    for (i in 1:Nsim) {

        print(i)
        df <- foo(200, sd = sd)
        mod <- rpart(y ~ ., data = df)
        modp <- prune(mod, 
            cp = mod$cptable[which.min(mod$cptable[,"xerror"]), 1])
        nmirpart[i] <- nmi(modp$where, attr(df, "where"))
        ntrpart[i] <- sum(modp$frame$var == "<leaf>")
        crpart[i] <- crrpart(modp)

        mod <- ctree(y ~ ., data = df, mincriterion = 0.95, 
                     testtype = "Bonferroni")
        nmictree[i] <- nmi(mod@where, attr(df, "where"))
        ntctree[i] <- nterminal(mod@tree)
        cctree[i] <- crctree(mod)
    }

    ret <- data.frame(nmirpart = nmirpart,
                      ntrpart = ntrpart,
                      nmictree = nmictree,
                      ntctree = ntctree,
                      crpart = crpart,
                      cctree = cctree)
    attr(ret, "sd") <- sd
    return(ret)
}

ret <- loop(Nsim, sd = 1)

save(ret, file = "ret.rda")
